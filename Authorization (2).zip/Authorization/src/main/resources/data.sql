INSERT  INTO users(name, email, username, password) VALUES('aarti','aarti@gmail.com','aarti','$2a$10$EZ97z/7u.uXuasBNG.xKaeUqMmCUEqVsEC1b5IOQQbFZxSxiV75ei');
	
INSERT  INTO users(name, email, username, password) VALUES('pratik','pratik@gmail.com','pratik','$2a$10$/AuRvxxb1WONZQ2TefhTEefz4C2AqZVFU/7Fp1L6J1UUfTryivqkG');
	
INSERT  INTO users(name, email, username, password) VALUES('chinmay','chinmay@gmail.com','chinmay','$2a$10$woO18aj56fFez5EpBmSaIOAAhCR89vO6TMSQ.EUfYB4btT7wDmkwy');
	
INSERT  INTO users(name, email, username, password) VALUES('akshaya','akshaya@gmail.com','akshaya','$2a$10$1RnjPAzBTyZXCNI8NMm1S.n6ErbLyKrolVIQWQxPO2SQQDujiawcm');
	