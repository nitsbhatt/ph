package com.medicine.stock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicine.stock.model.MedicineStock;
import com.medicine.stock.repository.MedicineStockRepo;

@Service
public class MedicineStockRepoService {
	
	@Autowired
	MedicineStockRepo  medicineStockRepo;
	
	
	public List<MedicineStock> getMedicineStockDeatils(){
		return medicineStockRepo.findAll();
	}

}
