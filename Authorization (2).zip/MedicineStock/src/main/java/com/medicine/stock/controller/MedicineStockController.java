package com.medicine.stock.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.medicine.stock.service.MedicineStockRepoService;

@RestController
public class MedicineStockController {
	
	@Autowired
	MedicineStockRepoService medicineStockService;
	
	@GetMapping("/medicine-stock-information")
	public ResponseEntity<?> getMedicineStock(){
		
		return new ResponseEntity<>(medicineStockService.getMedicineStockDeatils(),HttpStatus.OK);
	}

	
}
