package com.pharmacySupply;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.pharmacySupply.service.PharmacySupplyService;

@SpringBootTest
class PhamacySupplyModuleApplicationTests {

	@Autowired
	PharmacySupplyService pharmacyservice;

	@Test
	void TestInt() {

		int a = pharmacyservice.getMedicineStock(2, "Crosin");
		assertTrue(a > 0);
	}

	@Test
	void Test1() {

		int a = pharmacyservice.getMedicineStock(2, "Crosin");
		assertFalse(a < 0);
	}

	@Test
	void Test2() {

		int a = pharmacyservice.getMedicineStock(2, "Crosin");
		assertNotNull(a);
	}

	@Test
	void Test3() {

		int a = pharmacyservice.getMedicineStock(-10, "Crosin");
		assertEquals(-1, a);
	}

	@Test
	void Test4() {

		int a = pharmacyservice.getMedicineStock(9, "C");
		assertEquals(-2, a);
	}


}
