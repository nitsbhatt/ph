package com.pharmacySupply.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.pharmacySupply.Repository.PharmacySupplyRepo;

@Service
public class PharmacySupplyService {

	@Autowired
	PharmacySupplyRepo pharmacysupplyrepo;

	public int getMedicineStock(int demand_count, String m_name) {
		if(demand_count<0) {
			return -1;
		}
		try {
			int supply_count = (int) pharmacysupplyrepo.getSupplyCount(m_name);
			
			if (supply_count < demand_count) {
				return supply_count;
			} else {
				return demand_count;
			}
			
		}
		catch(Exception e){
			return -2;
		}
	
   }
	
	public List getPharmacymedicinesupply() {
		return pharmacysupplyrepo.findAll();
	}
}
