package com.pharmacySupply.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pharmacySupply.service.PharmacySupplyService;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class PharmacySupplyController {
	@Autowired
	PharmacySupplyService pharmacyservice;

	@GetMapping("/PharmacySupply")
		public ResponseEntity<?> getPharmacyMedicineSupply(){
		return new ResponseEntity<>(pharmacyservice.getPharmacymedicinesupply(),HttpStatus.OK);
			
		}
	
	@GetMapping("/pharmacy/{demandcount}/{medicinename}")
	public ResponseEntity<?> getMedicineStock(@PathVariable String medicinename, @PathVariable String demandcount) {
		int demand_c;
		int dc=0;
		try {
			demand_c = Integer.parseInt(demandcount);
		} 
		catch (Exception e) {
			return new ResponseEntity<>("Bad input", HttpStatus.BAD_REQUEST);
		}
		if(demand_c>0) {
			dc=demand_c;
		}
		else {
			return new ResponseEntity<>("Negative Count is not allowed", HttpStatus.BAD_REQUEST);
		}
	   try {
			return new ResponseEntity<>(pharmacyservice.getMedicineStock(dc, medicinename), HttpStatus.OK);

		}
       catch (Exception e) {
			return new ResponseEntity<>("This Medicine is not available", HttpStatus.BAD_REQUEST);
		}
	}
}
