package com.pharmacySupply.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pharmacySupply.model.PharmacyMedicineSupply;

@Repository
public interface PharmacySupplyRepo extends JpaRepository<PharmacyMedicineSupply, Integer> {

	@Query(value = "select supply_count from pharmacy_medicine_supply where medicine_name=:m_name", nativeQuery = true)
	public int getSupplyCount(@Param("m_name") String m_name);

}