package com.pharmacySupply.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url = "http://localhost:8082/medicine-stock", name = "medicine-stock-microservice")
public interface MedicineStockFeignClient {

	/*@GetMapping("/medicineByAilment/{targetAilment}")
    public void getMedicineByAilment(@PathVariable String targetAilment);
	*/
	@GetMapping("/medicine-stock-information")
	public ResponseEntity<?> getMedicineStock();

}
