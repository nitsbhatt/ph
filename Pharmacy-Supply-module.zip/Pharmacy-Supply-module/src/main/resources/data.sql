INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('mediplus','Paroxetine',1000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('medico','Remedesivir',1000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('cipla','Crosin',1000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('serum','Paracetomol',2000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('mediplus','Disprin',3200);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('mediplus','Aciloc',2400);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Prime Health Care','Coldflue',2679);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('ICareMedical','Metformin',1232);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('PunaMedical','Sitagilminpride',9002);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('HappinessForever','B29',6782);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Medicare','Calcium',2678);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Plus','Chlorinozol',2000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Pride Medical','Atrovastin',5000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('RoyalMedical','Omee',6000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('HelplineMedical','Cholecalciferol',7000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Drug House','Gaviscon',8000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('NiteshAartiMedico','Asprin',2675);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Jivan Medical','Dolo-650',9000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Pulses Chemist','Orthoherb',3000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('Wellness','Cyclopam',4000);
INSERT INTO pharmacy_medicine_supply(pharmacy_name,medicine_name,supply_count) VALUES('HealthCare','Hilact',5699);


/**********************data for medicine demand table ***************/

INSERT INTO medicine_demand(medicine,demand_count)VALUES('Cholecalciferol',700);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Paracetomol',500);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Crosin',60);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Dolo',800);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Asprin',90);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Hilact',170);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Orthoherb',20);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Atrovastin',80);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('B29',75);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('MeftalSpas',180);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Aciloc',65);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Disprin',75);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Coldflue',75);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Coldex',85);
INSERT INTO medicine_demand(medicine,demand_count)VALUES('Gaviscon',70);
